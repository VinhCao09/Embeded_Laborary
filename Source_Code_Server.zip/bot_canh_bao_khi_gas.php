<?php
$BOT_TOKEN = "7106862022:AAGscdm_QSei8Xmt0fDqJ9dzuM-3JF8fTxk";

$update = file_get_contents('php://input');
$update = json_decode($update, true);
$userChatId = $update["message"]["from"]["id"]?$update["message"]["from"]["id"]:null;

if($last_reading_gas==1){
    $userMessage = $update["message"]["text"]?$update["message"]["text"]:"Nothing";
    $firstName = $update["message"]["from"]["first_name"]?$update["message"]["from"]["first_name"]:"N/A";
    $lastName = $update["message"]["from"]["last_name"]?$update["message"]["from"]["last_name"]:"N/A";
    $fullName = $firstName." ".$lastName;
    $replyMsg = "CẢNH BÁO! \nCẢNH BÁO CÓ KHÍ GAS. \nTruy cập vinhcaodatabase.com/esp32/ để xem dữ liệu!";


    $parameters = array(
        "chat_id" => 2102482150,
        "text" => $replyMsg,
        "parseMode" => "html"
    );

    send("sendMessage", $parameters);
}

if($userChatId){
    $userMessage = $update["message"]["text"]?$update["message"]["text"]:"Nothing";
    $firstName = $update["message"]["from"]["first_name"]?$update["message"]["from"]["first_name"]:"N/A";
    $lastName = $update["message"]["from"]["last_name"]?$update["message"]["from"]["last_name"]:"N/A";
    $fullName = $firstName." ".$lastName;
    if($userMessage=="xin chao"or"xin chào") {$replyMsg = "Xin chào! ".$fullName."\nRất vui được gặp bạn! Tôi là Bot Canh Bao Khi Gas - Được xây dựng và phát triển bởi nhóm 3 trong môn TT Nhúng. \nBạn có thể ra lệnh cho tôi như sau: \n
nhiet do: để nhận dữ liệu nhiệt độ hiện tại
do am: để nhận dữ liệu độ ẩm hiện tại
khi gas: để nhận dữ liệu từ MQ2 đang thu thập được
info: để xem thông tin về nhóm tác giả
" ; }
    if($userMessage=="nhiet do") {$replyMsg = "Xin chào! ".$fullName."\nNhiệt độ đang đo được là: ".$last_reading_temp. " độ C"."\nLần nhận được dữ liệu là vào lúc\n".$last_reading_time; }
    if($userMessage=="do am") {$replyMsg = "Xin chào! ".$fullName."\nĐộ ẩm đang đo được là: ".$last_reading_humi. " %"."\nLần nhận được dữ liệu là vào lúc\n".$last_reading_time; }
    if($userMessage=="khi gas") {$replyMsg = "Xin chào! ".$fullName."\nHiện tại chúng tôi không phát hiện bất kỳ vấn đề bất thường nào về khí GAS"."\nLần nhận được dữ liệu là vào lúc\n".$last_reading_time; }
    if($userMessage=="info") {$replyMsg = "Thông tin tác giả:\n1. Cao Văn Vinh\n2. Trần Tuấn Việt\n3. Nguyễn Phúc Huy\nSĐT LH: 0865.700.435"; }


    $parameters = array(
        "chat_id" => $userChatId,
        "text" => $replyMsg,
        "parseMode" => "html"
    );

    send("sendMessage", $parameters);
}

function send($method, $data){
    global $BOT_TOKEN;
    $url = "https://api.telegram.org/bot$BOT_TOKEN/$method";

    if(!$curld = curl_init()){
        exit;
    }
    curl_setopt($curld, CURLOPT_POST, true);
    curl_setopt($curld, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curld, CURLOPT_URL, $url);
    curl_setopt($curld, CURLOPT_RETURNTRANSFER, true);
    $output = curl_exec($curld);
    curl_close($curld);
    return $output;
}

?>