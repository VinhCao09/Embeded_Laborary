<!DOCTYPE html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Đồ án TT Nhúng trong công nghiệp - Nhóm 3|Trang chủ</title>
    <link rel="icon" href="https://dongphucvina.vn/wp-content/uploads/2022/09/Logo-DH-Su-Pham-Ky-Thuat-TP-Ho-Chi-Minh-HCMUTE-623x800.webp">
        <link rel="stylesheet" type="text/css" href="esp-style.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script>
            $(document).ready(function() {
            $("#sensor-data").load("data_ajax.php"); // Load lai data

            //Thiet lap t/g reset
            setInterval(function() {
                $("#sensor-data").load("data_ajax.php");
            }, 5000); // Refresh every 5 seconds
            });
        </script>

    </head>
    <marquee width="100%" behavior="scroll" bgcolor="pink">  
    Hệ thống giám sát môi trường & cảnh báo khí Gas bằng Raspberry Pi giao tiếp với ESP8266 sử dụng cơ sở dữ liệu, website thông tin & cảnh báo qua Telegram - Nhóm 3 - Môn TT Hệ thống Nhúng trong công nghiệp - Khoa Điện - Điện tử - Trường Đại học Sư phạm Kỹ thuật TPHCM
</marquee>
    <header class="header">
    <h1> Giám sát môi trường và cảnh báo khí GAS tự động sử dụng Raspberry Pi - ESP8266 và báo cháy qua Telegram</h1>
    <h2> NHÓM 3 </h2>
    </header>
<body>

<div id="sensor-data">

</div> 
<section class="dieuhuong">
<a href="lich_su.php" target="_blank" class="btn btn-danger">XEM LỊCH SỬ GIÁM SÁT</a> 
<a href="https://t.me/CanhBaoKhiGasBot" target="_blank" style="color: green;">BOT TELEGRAM</a>
<br>
<p>Quét mã QR bên dưới để giao tiếp với chat bot</p>
<img src='qrcode.png'>
<br><br><br><br><br>
</section>


</body>
</html>