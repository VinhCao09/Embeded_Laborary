<!-- 2024 CODING BY VINHCAODATBASE.COM -->
<!-- SUPPORT PROJECT IOT - PHP - WEBSITE -->
<?php
$servername = "localhost";
$dbname = "example_esp_dat";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT id, sensor, location, value1, value2, value3, reading_time FROM SensorData ORDER BY id DESC";

$result = $conn->query($sql);

echo '<table class="table table-condensed table-hover">';
echo '<tr class="table-info "> 
        <td>ID</td> 
        <td>Sensor</td> 
        <td>Location</td> 
        <td>Nhiệt độ</td> 
        <td>Độ ẩm</td>
        <td>Khí Gas</td> 
        <td>Thời gian nhận dữ liệu</td> 
      </tr>';

if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
      $row_id = $row["id"];
      $row_sensor = $row["sensor"];
      $row_location = $row["location"];
      $row_value1 = $row["value1"];
      $row_value2 = $row["value2"]; 
      $row_value3 = $row["value3"]; 
      $row_reading_time = $row["reading_time"];
      if($row_value3==0){
        echo '<tr> 
        <td class="table-warning">' . $row_id . '</td> 
        <td>' . $row_sensor . '</td> 
        <td>' . $row_location . '</td> 
        <td>' . $row_value1 . '</td> 
        <td>' . $row_value2 . '</td>
        <td>' . $row_value3 . '</td> 
        <td>' . $row_reading_time . '</td> 
      </tr>';
       }
       if($row_value3==1){
        echo '<tr> 
        <td class="table-warning">' . $row_id . '</td> 
        <td>' . $row_sensor . '</td> 
        <td>' . $row_location . '</td> 
        <td>' . $row_value1 . '</td> 
        <td>' . $row_value2 . '</td>
        <td class="table-danger">' . $row_value3 . '</td> 
        <td>' . $row_reading_time . '</td> 
      </tr>';
       }
      //include_once('bot_canh_bao_khi_gas.php'); code trong web chính thì bỏ này vào

  }
} else {
  echo "<tr><td colspan='7'>No data found</td></tr>";
}

$conn->close();
echo '</table>';
?>
