<!-- 2024 CODING BY VINHCAODATBASE.COM -->
<!-- SUPPORT PROJECT IOT - PHP - WEBSITE -->
<!DOCTYPE html>
<html>
<head>
<title>Đồ án TT Nhúng trong công nghiệp - Nhóm 3|Lịch sử dữ liệu</title>
    <link rel="icon" href="https://dongphucvina.vn/wp-content/uploads/2022/09/Logo-DH-Su-Pham-Ky-Thuat-TP-Ho-Chi-Minh-HCMUTE-623x800.webp">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
$(document).ready(function() {
  $("#sensor-data").load("get_sensor_data.php"); // Load lai data

 //Thiet lap t/g reset
  setInterval(function() {
    $("#sensor-data").load("get_sensor_data.php");
  }, 5000); // Refresh every 5 seconds
});
</script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

</head>
<body>

<div class="container">
  <div class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top"> 
      <div class="col-1"></div>
      <div class="col-3">
      <img style="width: 30px;" src="https://dongphucvina.vn/wp-content/uploads/2022/09/Logo-DH-Su-Pham-Ky-Thuat-TP-Ho-Chi-Minh-HCMUTE.webp" class="rounded" alt="Cinque Terre">
      </div>
  <div class="col-1"></div>
  <div class="col-6 text-info">Lịch sử bảng ghi</div>
  <div class="col-1"><a href="index.php" class="btn btn-success">Quay lại</a></div>
</div>
<br>
<br>
<br>


    <div id="sensor-data"></div>

        
    <div class="navbar navbar-expand-sm bg-dark navbar-dark fixed-bottom"> 
      <div class="col-1"></div>
      <div class="col-11 text-primary"><marquee>Đồ án TT Hệ thống Nhúng trong công nghiệp - GIÁM SÁT MÔI TRƯỜNG VÀ CẢNH BÁO KHÍ GAS TỰ ĐỘNG SỬ DỤNG RASPBERRY PI - ESP8266 VÀ BÁO CHÁY QUA TELEGRAM - Nhóm 3 </marquee></div>
    </div>

<!-- <div id="sensor-data"></div> -->
</body>
</html>